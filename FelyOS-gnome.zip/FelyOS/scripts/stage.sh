#!/bin/sh
# Copy project sources into the live-build includes tree.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INC="$ROOT/iso/config/includes.chroot"
rm -rf "$INC/usr/lib/python3/dist-packages/felyos"
mkdir -p "$INC/usr/lib/python3/dist-packages" "$INC/usr/local/bin" "$INC/usr/share/felyos/branding" \
         "$INC/usr/share/felyos/locales" "$INC/usr/share/felyos/icons" "$INC/usr/share/felyos/wallpaper" \
         "$INC/usr/share/applications" "$INC/usr/share/mime/packages" "$INC/etc/xdg" \
         "$INC/usr/src/felyos-native" "$INC/etc/felyos"
cp -r "$ROOT/src/python/felyos" "$INC/usr/lib/python3/dist-packages/"
find "$INC/usr/lib/python3/dist-packages/felyos" -name __pycache__ -prune -exec rm -rf {} +
cp "$ROOT"/tools/* "$INC/usr/local/bin/"
install -m 0755 "$ROOT/scripts/create-persistence.sh" "$INC/usr/local/bin/felyos-create-persistence"
cp "$ROOT"/assets/branding/* "$INC/usr/share/felyos/branding/"
cp "$ROOT"/assets/icons/* "$INC/usr/share/felyos/icons/"
cp "$ROOT"/locales/*.json "$INC/usr/share/felyos/locales/"
cp "$ROOT"/src/cpp/* "$INC/usr/src/felyos-native/"
cp "$ROOT/assets/wallpaper/felyos.jpg" "$INC/usr/share/felyos/wallpaper/"
cp "$ROOT/config/felyos-release" "$INC/etc/felyos-release"
cp "$ROOT/config/settings.conf" "$INC/etc/felyos/settings.conf"
cp "$ROOT/config/fely-wine.desktop" "$ROOT/config/fely-open.desktop" "$INC/usr/share/applications/"
cp "$ROOT/config/felyos-exe.xml" "$ROOT/config/felyos-code.xml" "$INC/usr/share/mime/packages/"
cp "$ROOT/config/mimeapps.list" "$INC/etc/xdg/mimeapps.list"
mkdir -p "$INC/etc/polkit-1"
echo "Staged."
