#!/bin/sh
# Create a persistence filesystem on a separate USB/disk partition.
# Usage: sudo ./scripts/create-persistence.sh /dev/sdX2
set -eu
DEV="${1:-}"
[ -n "$DEV" ] || { echo "Usage: sudo $0 /dev/sdX2"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
command -v mkfs.ext4 >/dev/null || { echo "e2fsprogs is required."; exit 1; }
mkfs.ext4 -F -L persistence "$DEV"
MNT="$(mktemp -d)"
mount "$DEV" "$MNT"
cat > "$MNT/persistence.conf" <<'CONF'
/ union
CONF
sync
umount "$MNT"
rmdir "$MNT"
echo "Persistence enabled on $DEV. Boot FelyOS with the persistence option."
