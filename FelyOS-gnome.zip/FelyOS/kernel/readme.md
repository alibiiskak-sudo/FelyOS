# kernel
Kernel: FelyOS 0.1 uses the stock Debian kernel (linux-image-amd64). Custom config goes here later.
