"""`fely` command line tool. Never uses a shell; all subprocess calls are argv lists."""
import argparse
import os
import re
import subprocess
import sys

from . import info
from .i18n import t

TEMPLATES = {
    "python": {
        "main.py": 'def main():\n    print("Hello from {name}!")\n\n\nif __name__ == "__main__":\n    main()\n',
        "README.md": "# {name}\n\nRun: `python3 main.py`\n",
    },
    "cpp": {
        "main.cpp": '#include <iostream>\n\nint main() {{\n    std::cout << "Hello from {name}!" << std::endl;\n    return 0;\n}}\n',
        "CMakeLists.txt": "cmake_minimum_required(VERSION 3.16)\nproject({name} CXX)\nset(CMAKE_CXX_STANDARD 17)\nadd_executable({name} main.cpp)\n",
        "README.md": "# {name}\n\nBuild: `cmake -B build && cmake --build build`\n",
    },
}


def run(argv):
    try:
        return subprocess.call(argv)
    except FileNotFoundError:
        print("command not found: %s" % argv[0], file=sys.stderr)
        return 127


def cmd_help(a):
    print("FelyOS %s\n" % info.version())
    print("Usage: fely <command>\n")
    for c, d in [
        ("help", "show this help"), ("version", "show FelyOS version"),
        ("info", "show FelyOS system information (also: fely-info)"),
        ("update", "update Debian package lists and upgrade (sudo)"),
        ("pip-install <package...>", "install Python packages with pip"),
        ("install <pkg...>", "install Debian packages (sudo)"),
        ("settings", "show settings file"), ("reboot", "reboot"), ("shutdown", "power off"),
        ("create-project <name> [--lang python|cpp]", "create a project template"),
    ]:
        print("  %-44s %s" % (c, d))
    return 0


def cmd_version(a):
    print("FelyOS %s" % info.version())
    return 0


def cmd_info(a):
    print()
    print(info.render(info.full()))
    return 0


def cmd_update(a):
    return run(["sudo", "apt-get", "update"]) or run(["sudo", "apt-get", "upgrade"])


def cmd_install(a):
    if not a.packages:
        print("usage: fely install <package...>")
        return 2
    return run(["sudo", "apt-get", "install"] + a.packages)


def cmd_pip_install(a):
    if not a.packages:
        print("usage: fely pip-install <package...>")
        return 2
    return run(["python3", "-m", "pip", "install", "--break-system-packages"] + a.packages)


def cmd_settings(a):
    for p in (os.path.expanduser("~/.config/felyos/settings.conf"), "/etc/felyos/settings.conf"):
        if os.path.isfile(p):
            print("# " + p)
            print(open(p, encoding="utf-8").read())
            return 0
    print("No settings file found.")
    return 0


def cmd_reboot(a):
    return run(["systemctl", "reboot"])


def cmd_shutdown(a):
    return run(["systemctl", "poweroff"])


def cmd_create(a):
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", a.name):
        print(t("cli.badname"), file=sys.stderr)
        return 2
    path = os.path.abspath(a.name)
    if os.path.exists(path):
        print(t("cli.exists", path=path), file=sys.stderr)
        return 1
    os.makedirs(path)
    for fname, body in TEMPLATES[a.lang].items():
        with open(os.path.join(path, fname), "w", encoding="utf-8") as f:
            f.write(body.format(name=a.name))
    print(t("cli.created", lang=a.lang, path=path))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="fely", add_help=False)
    sub = p.add_subparsers(dest="cmd")
    for name, fn in [("help", cmd_help), ("version", cmd_version), ("info", cmd_info), ("pip-install", cmd_pip_install),
                     ("update", cmd_update), ("settings", cmd_settings),
                     ("reboot", cmd_reboot), ("shutdown", cmd_shutdown)]:
        sub.add_parser(name).set_defaults(fn=fn)
    s = sub.add_parser("install")
    s.add_argument("packages", nargs="*")
    s.set_defaults(fn=cmd_install)
    c = sub.add_parser("create-project")
    c.add_argument("name")
    c.add_argument("--lang", choices=sorted(TEMPLATES), default="python")
    c.set_defaults(fn=cmd_create)
    args = p.parse_args(argv)
    if not getattr(args, "fn", None):
        return cmd_help(args)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
