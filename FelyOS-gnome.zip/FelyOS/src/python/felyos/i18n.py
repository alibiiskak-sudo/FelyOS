"""Tiny JSON-based localization. Falls back to English, then to the key."""
import json
import os

_DIRS = [
    "/usr/share/felyos/locales",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "locales"),
]
_cache = {}


def _load(lang):
    if lang in _cache:
        return _cache[lang]
    data = {}
    for d in _DIRS:
        p = os.path.join(d, lang + ".json")
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    data = json.load(f)
                break
            except (OSError, ValueError):
                pass
    _cache[lang] = data
    return data


def language():
    lang = os.environ.get("FELYOS_LANG") or os.environ.get("LANG", "en")
    return (lang.split("_")[0].split(".")[0] or "en").lower()


def t(key, **kw):
    text = _load(language()).get(key) or _load("en").get(key) or key
    try:
        return text.format(**kw)
    except (KeyError, IndexError):
        return text
