"""FelyOS shell: taskbar (apps, clock, power) + app windows with traffic-light buttons. GTK3 + VTE."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("Vte", "2.91")
gi.require_version("GdkX11", "3.0")
from gi.repository import GdkX11  # noqa: E402,F401
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango, Vte  # noqa: E402

from .i18n import t  # noqa: E402

LOGO_PATHS = ["/usr/share/felyos/branding/logo.svg",
              os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "assets", "branding", "logo.svg")]
ICON_DIRS = ["/usr/share/felyos/icons",
             os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "assets", "icons")]
FLAG = os.path.expanduser("~/.config/felyos/welcome_done")

CSS = b"""
window, .root { background: #0b0d14; }
.bg { background-image: radial-gradient(circle at 20% 15%, rgba(79,140,255,0.18), transparent 45%),
                        radial-gradient(circle at 85% 90%, rgba(139,92,246,0.18), transparent 45%); }
.card { background: #141824; border-radius: 24px; padding: 48px 56px;
        border: 1px solid rgba(255,255,255,0.06); }
.title { color: #ffffff; font-size: 30px; font-weight: 700; }
.tagline { color: #9aa4bf; font-size: 16px; }
.cta { background-image: linear-gradient(135deg, #4f8cff, #8b5cf6); color: #fff; border: none;
       border-radius: 14px; padding: 12px 36px; font-size: 16px; font-weight: 600; }
.cta:hover { opacity: 0.9; }
headerbar { background: #0f121b; border-bottom: 1px solid rgba(255,255,255,0.06); color: #e6e9f2; padding: 0 8px; }
headerbar .title { color: #e6e9f2; font-size: 13px; font-weight: 600; }
.tl { min-width: 13px; min-height: 13px; padding: 0; margin: 0 3px; border: none; box-shadow: none;
      background-image: none; border-radius: 999px; }
.tl:hover { opacity: 0.75; }
.tl-close { background-color: #ff5f57; }
.tl-min { background-color: #febc2e; }
.tl-full { background-color: #28c840; }
notebook, notebook > stack { background: #0b0d14; }
notebook > header { background: #0f121b; border: none; }
notebook > header button { color: #e6e9f2; }
notebook tab { background: #0f121b; color: #9aa4bf; border-radius: 10px 10px 0 0; padding: 4px 10px; }
notebook tab:checked { background: #141824; color: #fff; }
.taskbar { background: #0f121b; border-top: 1px solid rgba(255,255,255,0.08); padding: 6px 10px; }
.task-btn { background-image: none; background-color: transparent; border: none; box-shadow: none;
            border-bottom: 2px solid transparent; border-radius: 10px; padding: 6px 14px; color: #e6e9f2; }
.task-btn:hover { background-color: rgba(255,255,255,0.08); }
.task-btn.open { border-bottom-color: rgba(255,255,255,0.35); }
.task-btn.active { background-color: rgba(79,140,255,0.22); border-bottom-color: #4f8cff; }
.clock-time { color: #ffffff; font-size: 15px; font-weight: 600; }
.clock-date { color: #9aa4bf; font-size: 11px; }
.battery { color: #e6e9f2; padding: 0 4px; }
menu { background-color: #141824; color: #e6e9f2; border: 1px solid rgba(255,255,255,0.1);
       border-radius: 8px; padding: 4px; }
menuitem { padding: 8px 16px; border-radius: 6px; }
menuitem:hover { background-color: rgba(79,140,255,0.25); }
.np-bar { background: #0f121b; padding: 6px 10px; border-bottom: 1px solid rgba(255,255,255,0.06); }
.np-bar button { color: #e6e9f2; background-image: none; background-color: transparent; border: none; box-shadow: none; }
.np-bar button:hover { background-color: rgba(255,255,255,0.08); }
.np-name { color: #9aa4bf; }
.notepad textview, .notepad textview text { background-color: #0b0d14; color: #e6e9f2;
                                            font-family: "JetBrains Mono", monospace; font-size: 12px; }
"""


def _logo(size):
    for p in LOGO_PATHS:
        if os.path.isfile(p):
            try:
                return Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_size(p, size, size))
            except GLib.Error:
                pass
    return Gtk.Label(label="F")


def _icon(name, fallback, size=22):
    for d in ICON_DIRS:
        p = os.path.join(d, name + ".svg")
        if os.path.isfile(p):
            try:
                return Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_size(p, size, size))
            except GLib.Error:
                pass
    return Gtk.Image.new_from_icon_name(fallback, Gtk.IconSize.LARGE_TOOLBAR)


def rgba(h):
    c = Gdk.RGBA()
    c.parse(h)
    return c


class Notepad(Gtk.Box):
    """Minimal text editor: new / open / save / save as."""

    def __init__(self, win):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.win, self.path, self.dirty = win, None, False
        self.get_style_context().add_class("notepad")
        bar = Gtk.Box(spacing=4)
        bar.get_style_context().add_class("np-bar")
        for icon, key, cb in [("document-new-symbolic", "notepad.new", self.new),
                              ("document-open-symbolic", "notepad.open", self.open),
                              ("document-save-symbolic", "notepad.save", self.save),
                              ("document-save-as-symbolic", "notepad.save_as", self.save_as)]:
            b = Gtk.Button.new_from_icon_name(icon, Gtk.IconSize.BUTTON)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.set_tooltip_text(t(key))
            b.connect("clicked", lambda _b, f=cb: f())
            bar.pack_start(b, False, False, 0)
        self.name = Gtk.Label(xalign=0, ellipsize=Pango.EllipsizeMode.MIDDLE)
        self.name.get_style_context().add_class("np-name")
        bar.pack_start(self.name, True, True, 12)
        self.pack_start(bar, False, False, 0)
        self.view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, left_margin=14, right_margin=14,
                                 top_margin=12, bottom_margin=12)
        self.buf = self.view.get_buffer()
        self.buf.connect("changed", self._changed)
        sw = Gtk.ScrolledWindow(vexpand=True)
        sw.add(self.view)
        self.pack_start(sw, True, True, 0)
        self._label()

    def focus(self):
        self.view.grab_focus()

    def _label(self):
        name = os.path.basename(self.path) if self.path else t("notepad.untitled")
        self.name.set_text(("\u25cf " if self.dirty else "") + name)

    def _changed(self, *_):
        self.dirty = True
        self._label()

    def _set_text(self, text, path):
        self.buf.set_text(text)
        self.path, self.dirty = path, False
        self._label()

    def _error(self):
        d = Gtk.MessageDialog(parent=self.win, modal=True, message_type=Gtk.MessageType.ERROR,
                              buttons=Gtk.ButtonsType.CLOSE, text=t("notepad.error"))
        d.run()
        d.destroy()

    def confirm_discard(self):
        """True if it is safe to drop the current text (saved, discarded, or nothing to lose)."""
        if not self.dirty:
            return True
        d = Gtk.MessageDialog(parent=self.win, modal=True, message_type=Gtk.MessageType.QUESTION,
                              text=t("notepad.unsaved"))
        d.add_button(t("notepad.cancel"), Gtk.ResponseType.CANCEL)
        d.add_button(t("notepad.discard"), Gtk.ResponseType.REJECT)
        d.add_button(t("notepad.save"), Gtk.ResponseType.ACCEPT)
        r = d.run()
        d.destroy()
        if r == Gtk.ResponseType.ACCEPT:
            return self.save()
        return r == Gtk.ResponseType.REJECT

    def _chooser(self, action, accept_key):
        d = Gtk.FileChooserDialog(parent=self.win, action=action)
        d.add_button(t("notepad.cancel"), Gtk.ResponseType.CANCEL)
        d.add_button(t(accept_key), Gtk.ResponseType.OK)
        d.set_current_folder(os.path.expanduser("~"))
        return d

    def new(self):
        if self.confirm_discard():
            self._set_text("", None)

    def open(self):
        if not self.confirm_discard():
            return
        d = self._chooser(Gtk.FileChooserAction.OPEN, "notepad.open")
        path = d.get_filename() if d.run() == Gtk.ResponseType.OK else None
        d.destroy()
        if path:
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    self._set_text(f.read(), path)
            except OSError:
                self._error()

    def save(self):
        if not self.path:
            return self.save_as()
        return self._write(self.path)

    def save_as(self):
        d = self._chooser(Gtk.FileChooserAction.SAVE, "notepad.save")
        d.set_do_overwrite_confirmation(True)
        d.set_current_name("untitled.txt")
        path = d.get_filename() if d.run() == Gtk.ResponseType.OK else None
        d.destroy()
        return bool(path) and self._write(path)

    def _write(self, path):
        text = self.buf.get_text(self.buf.get_start_iter(), self.buf.get_end_iter(), True)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            self._error()
            return False
        self.path, self.dirty = path, False
        self._label()
        return True


class AppWindow(Gtk.Window):
    """Window with macOS-style buttons: red = close, yellow = minimize, green = fill the screen
    (taskbar stays visible). F11 = true full screen (title bar and taskbar hidden)."""

    def __init__(self, title, size):
        super().__init__()
        self.set_default_size(*size)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.iconified = False
        self._full = self._max = False
        self.hb = Gtk.HeaderBar(title=title)
        for cls, tip, cb in [("tl-close", "window.close", lambda *_: self.close()),
                             ("tl-min", "window.minimize", lambda *_: self.iconify()),
                             ("tl-full", "window.maximize", lambda *_: self.toggle_max())]:
            b = Gtk.Button(valign=Gtk.Align.CENTER, can_focus=False)
            b.set_tooltip_text(t(tip))
            b.get_style_context().add_class("tl")
            b.get_style_context().add_class(cls)
            b.connect("clicked", cb)
            self.hb.pack_start(b)
        self.set_titlebar(self.hb)
        self.connect("window-state-event", self._on_state)
        self.connect("key-press-event", self._on_f11)

    def _on_state(self, _w, ev):
        st = ev.new_window_state
        self._full = bool(st & Gdk.WindowState.FULLSCREEN)
        self._max = bool(st & Gdk.WindowState.MAXIMIZED)
        self.iconified = bool(st & Gdk.WindowState.ICONIFIED)

    def _on_f11(self, _w, ev):
        if ev.keyval == Gdk.KEY_F11:
            self.toggle_full()
            return True
        return False

    def toggle_max(self):
        if self._max:
            self.unmaximize()
        else:
            self.maximize()

    def toggle_full(self):
        if self._full:
            self.unfullscreen()
        else:
            self.fullscreen()


class WelcomeWindow(AppWindow):
    def __init__(self, on_start):
        super().__init__(t("welcome.title"), (860, 560))
        outer = Gtk.Box()
        outer.get_style_context().add_class("bg")
        self.card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14,
                            halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.card.get_style_context().add_class("card")
        self.card.pack_start(_logo(96), False, False, 0)
        title = Gtk.Label(label=t("welcome.title"))
        title.get_style_context().add_class("title")
        tag = Gtk.Label(label=t("welcome.tagline"))
        tag.get_style_context().add_class("tagline")
        btn = Gtk.Button(label=t("welcome.button"), halign=Gtk.Align.CENTER)
        btn.get_style_context().add_class("cta")
        btn.connect("clicked", lambda *_: on_start())
        for w in (title, tag):
            self.card.pack_start(w, False, False, 0)
        self.card.pack_start(btn, False, False, 14)
        outer.set_center_widget(self.card)
        self.add(outer)
        self._fade_in()

    def _fade_in(self):
        self.card.set_opacity(0)
        state = {"o": 0.0}

        def step():
            state["o"] = min(1.0, state["o"] + 0.04)
            self.card.set_opacity(state["o"])
            return state["o"] < 1.0
        GLib.timeout_add(16, step)


class TerminalWindow(AppWindow):
    def __init__(self):
        super().__init__(t("terminal.title"), (980, 600))
        self.nb = Gtk.Notebook(scrollable=True)
        plus = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON)
        plus.set_relief(Gtk.ReliefStyle.NONE)
        plus.connect("clicked", lambda *_: self.new_tab())
        plus.show()
        self.nb.set_action_widget(plus, Gtk.PackType.END)
        self.add(self.nb)
        self.connect("key-press-event", self._on_key)
        self.new_tab()

    def new_tab(self):
        term = Vte.Terminal()
        term.set_font(Pango.FontDescription("JetBrains Mono 11"))
        term.set_scrollback_lines(10000)
        term.set_colors(rgba("#e6e9f2"), rgba("#0b0d14"), None)
        term.set_cursor_blink_mode(Vte.CursorBlinkMode.ON)
        env = ["%s=%s" % kv for kv in os.environ.items()] + ["FELYOS=1", "TERM=xterm-256color"]
        shell = os.environ.get("SHELL", "/bin/bash")
        term.spawn_async(Vte.PtyFlags.DEFAULT, os.path.expanduser("~"), [shell], env,
                         GLib.SpawnFlags.DEFAULT, None, None, -1, None, None)
        term.connect("child-exited", lambda *_: self._closed(term))
        label = Gtk.Label(label="Terminal %d" % (self.nb.get_n_pages() + 1))
        idx = self.nb.append_page(term, label)
        self.nb.set_tab_reorderable(term, True)
        term.show_all()
        self.nb.set_current_page(idx)
        term.grab_focus()

    def _closed(self, term):
        i = self.nb.page_num(term)
        if i >= 0:
            self.nb.remove_page(i)
        if self.nb.get_n_pages() == 0:
            self.destroy()

    def _on_key(self, _w, ev):
        ctrl_shift = Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.SHIFT_MASK
        if (ev.state & ctrl_shift) != ctrl_shift:
            return False
        k = Gdk.keyval_name(ev.keyval).lower()
        term = self.nb.get_nth_page(self.nb.get_current_page())
        if k == "c" and term:
            term.copy_clipboard_format(Vte.Format.TEXT)
        elif k == "v" and term:
            term.paste_clipboard()
        elif k == "t":
            self.new_tab()
        elif k == "w" and term:
            self._closed(term)
        else:
            return False
        return True


class NotepadWindow(AppWindow):
    def __init__(self):
        super().__init__(t("notepad.title"), (760, 520))
        self.notepad = Notepad(self)
        self.add(self.notepad)
        self.connect("delete-event", lambda *_: not self.notepad.confirm_discard())
        self.connect("key-press-event", self._on_key)
        self.notepad.focus()

    def _on_key(self, _w, ev):
        if not ev.state & Gdk.ModifierType.CONTROL_MASK:
            return False
        k = Gdk.keyval_name(ev.keyval).lower()
        if k == "s":
            self.notepad.save_as() if ev.state & Gdk.ModifierType.SHIFT_MASK else self.notepad.save()
        elif k == "o":
            self.notepad.open()
        elif k == "n":
            self.notepad.new()
        else:
            return False
        return True


class NetworkWindow(AppWindow):
    """Small NetworkManager front-end for Wi-Fi and Ethernet."""
    def __init__(self):
        super().__init__(t("network.title"), (760, 540))
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        root.set_border_width(16)

        header = Gtk.Box(spacing=10)
        self.status = Gtk.Label(xalign=0)
        self.status.get_style_context().add_class("tagline")
        refresh = Gtk.Button(label=t("network.refresh"))
        refresh.connect("clicked", lambda *_: self.refresh())
        header.pack_start(self.status, True, True, 0)
        header.pack_end(refresh, False, False, 0)
        root.pack_start(header, False, False, 0)

        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.listbox.set_vexpand(True)
        sw = Gtk.ScrolledWindow()
        sw.add(self.listbox)
        root.pack_start(sw, True, True, 0)

        hint = Gtk.Label(label=t("network.hint"), xalign=0)
        hint.get_style_context().add_class("tagline")
        root.pack_start(hint, False, False, 0)
        self.add(root)
        self.refresh()

    @staticmethod
    def _run(argv):
        try:
            return subprocess.run(argv, text=True, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, check=False, timeout=8)
        except (OSError, subprocess.SubprocessError):
            return None

    def _clear(self):
        for child in self.listbox.get_children():
            self.listbox.remove(child)

    def _row(self, title, subtitle, button_label=None, callback=None):
        box = Gtk.Box(spacing=12)
        box.set_border_width(10)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        h = Gtk.Label(label=title, xalign=0)
        h.get_style_context().add_class("title")
        h.set_markup("<span size='large' weight='600'>%s</span>" % GLib.markup_escape_text(title))
        sub = Gtk.Label(label=subtitle, xalign=0, wrap=True)
        sub.get_style_context().add_class("tagline")
        text.pack_start(h, False, False, 0)
        text.pack_start(sub, False, False, 0)
        box.pack_start(text, True, True, 0)
        if button_label and callback:
            b = Gtk.Button(label=button_label)
            b.connect("clicked", callback)
            box.pack_end(b, False, False, 0)
        self.listbox.add(box)

    def refresh(self):
        self._clear()
        state = self._run(["nmcli", "-t", "-f", "STATE", "general"])
        state_text = (state.stdout.strip() if state else "") or t("network.unavailable")
        self.status.set_text(t("network.manager") + ": " + state_text)

        devices = self._run(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"])
        if devices and devices.returncode == 0:
            for line in devices.stdout.splitlines():
                parts = line.split(":", 3)
                if len(parts) != 4:
                    continue
                dev, typ, st, conn = parts
                if typ not in ("wifi", "ethernet"):
                    continue
                pretty = t("network.wifi") if typ == "wifi" else t("network.ethernet")
                conn = conn or t("network.none")
                self._row(pretty + " — " + dev,
                          "%s: %s  |  %s: %s" % (t("network.state"), st, t("network.connection"), conn))

        wifi = self._run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY,IN-USE", "dev", "wifi", "list"])
        if wifi and wifi.returncode == 0:
            for line in wifi.stdout.splitlines():
                parts = line.rsplit(":", 3)
                if len(parts) != 4:
                    continue
                ssid, signal, security, in_use = parts
                if not ssid:
                    continue
                label = t("network.connected") if in_use.strip() == "*" else t("network.connect")
                self._row("Wi-Fi: " + ssid,
                          "%s: %s%%  |  %s: %s" % (t("network.signal"), signal or "0", t("network.security"), security or t("network.open")),
                          label,
                          lambda _b, n=ssid, sec=security: self._connect_wifi(n, sec))

        if not self.listbox.get_children():
            self._row(t("network.no_devices"), t("network.check"))
        self.listbox.show_all()

    def _connect_wifi(self, ssid, security):
        if security and security.upper() != "--":
            d = Gtk.Dialog(title=t("network.password_title"), transient_for=self, modal=True)
            d.add_button(t("notepad.cancel"), Gtk.ResponseType.CANCEL)
            d.add_button(t("network.connect"), Gtk.ResponseType.OK)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=14)
            box.pack_start(Gtk.Label(label=t("network.password_for") % ssid, xalign=0), False, False, 0)
            entry = Gtk.Entry()
            entry.set_visibility(False)
            box.pack_start(entry, False, False, 0)
            d.get_content_area().add(box)
            d.show_all()
            ok = d.run() == Gtk.ResponseType.OK
            password = entry.get_text()
            d.destroy()
            if not ok:
                return
            result = self._run(["nmcli", "dev", "wifi", "connect", ssid, "password", password])
        else:
            result = self._run(["nmcli", "dev", "wifi", "connect", ssid])
        if result and result.returncode != 0:
            md = Gtk.MessageDialog(parent=self, modal=True, message_type=Gtk.MessageType.ERROR,
                                   buttons=Gtk.ButtonsType.CLOSE, text=result.stderr.strip() or t("network.connect_failed"))
            md.run(); md.destroy()
        self.refresh()


class WineLauncherWindow(AppWindow):
    """FelyOS launcher for Windows .exe/.msi files through Wine."""
    def __init__(self):
        super().__init__(t("wine.title"), (720, 420))
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, margin=18)

        intro = Gtk.Label(label=t("wine.intro"), xalign=0, wrap=True)
        intro.get_style_context().add_class("tagline")
        root.pack_start(intro, False, False, 0)

        status = t("wine.installed") if shutil.which("wine") else t("wine.missing")
        self.status = Gtk.Label(label=status, xalign=0)
        self.status.get_style_context().add_class("tagline")
        root.pack_start(self.status, False, False, 0)

        self.path_label = Gtk.Label(label=t("wine.no_file"), xalign=0, ellipsize=Pango.EllipsizeMode.MIDDLE)
        root.pack_start(self.path_label, False, False, 0)

        actions = Gtk.Box(spacing=10)
        choose = Gtk.Button(label=t("wine.choose"))
        choose.connect("clicked", lambda *_: self.choose())
        run = Gtk.Button(label=t("wine.run"))
        run.get_style_context().add_class("cta")
        run.connect("clicked", lambda *_: self.run_selected())
        actions.pack_start(choose, False, False, 0)
        actions.pack_start(run, False, False, 0)
        root.pack_start(actions, False, False, 0)

        hint = Gtk.Label(label=t("wine.hint"), xalign=0, wrap=True)
        hint.get_style_context().add_class("tagline")
        root.pack_end(hint, False, False, 0)
        self.add(root)
        self.path = None

    def choose(self):
        d = Gtk.FileChooserDialog(parent=self, action=Gtk.FileChooserAction.OPEN)
        d.add_button(t("notepad.cancel"), Gtk.ResponseType.CANCEL)
        d.add_button(t("wine.choose"), Gtk.ResponseType.OK)
        exe = Gtk.FileFilter()
        exe.set_name(t("wine.filter_windows"))
        exe.add_pattern("*.exe")
        exe.add_pattern("*.EXE")
        exe.add_pattern("*.msi")
        exe.add_pattern("*.MSI")
        d.add_filter(exe)
        all_files = Gtk.FileFilter()
        all_files.set_name(t("wine.filter_all"))
        all_files.add_pattern("*")
        d.add_filter(all_files)
        d.set_current_folder(os.path.expanduser("~"))
        if d.run() == Gtk.ResponseType.OK:
            self.path = d.get_filename()
            self.path_label.set_text(self.path or t("wine.no_file"))
        d.destroy()

    def run_selected(self):
        if not self.path:
            return self.choose()
        if not shutil.which("wine"):
            self.status.set_text(t("wine.missing"))
            return
        try:
            subprocess.Popen(["wine", self.path],
                             env={**os.environ, "WINEDEBUG": "-all"},
                             cwd=os.path.dirname(self.path) or os.path.expanduser("~"))
            self.status.set_text(t("wine.started"))
        except OSError as exc:
            self.status.set_text(t("wine.error") + ": " + str(exc))


def _set_class(widget, name, on):
    ctx = widget.get_style_context()
    if on:
        ctx.add_class(name)
    else:
        ctx.remove_class(name)


def _run_power(cmd):
    """cmd is 'reboot' or 'poweroff'. argv lists only, no shell."""
    for argv in (["systemctl", cmd], ["sudo", "-n", "systemctl", cmd]):
        try:
            if subprocess.call(argv) == 0:
                return True
        except FileNotFoundError:
            pass
    return False


class Taskbar(Gtk.Window):
    """Bottom panel: app buttons (open / minimize / restore), power menu, clock."""
    HEIGHT = 52
    APPS = [("terminal", "terminal-2", "utilities-terminal", "taskbar.terminal", TerminalWindow),
            ("notepad", "notes", "accessories-text-editor", "taskbar.notepad", NotepadWindow),
            ("network", "network", "network-workgroup", "taskbar.network", NetworkWindow),
            ("wine", "applications", "application-x-executable", "taskbar.windows_apps", WineLauncherWindow)]
    # external programs: (id, icon, fallback icon, label key, argv)
    LAUNCHERS = [("files", "folder", "system-file-manager", "taskbar.files", ["thunar"]),
                 ("firefox", "browser", "web-browser", "taskbar.browser", ["firefox-esr"])]

    def __init__(self):
        super().__init__()
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        mon = Gdk.Display.get_default().get_monitor(0)
        self.geo = mon.get_geometry() if mon else Gdk.Rectangle()
        self.set_size_request(self.geo.width, self.HEIGHT)
        self.move(self.geo.x, self.geo.y + self.geo.height - self.HEIGHT)
        self.wins, self.btns, self.welcome = {}, {}, None
        self.procs, self.spawned = {}, []
        self.connect("realize", self._reserve_space)
        self.connect("destroy", Gtk.main_quit)

        bar = Gtk.Box(spacing=6)
        bar.get_style_context().add_class("taskbar")
        entries = [(a[0], a[1], a[2], a[3], lambda v=a[0]: self.toggle(v)) for a in self.APPS]
        entries += [(l[0], l[1], l[2], l[3], lambda v=l[0], c=l[4]: self.launch(v, c)) for l in self.LAUNCHERS]
        for view, icon, fallback, key, action in entries:
            box = Gtk.Box(spacing=8)
            box.pack_start(_icon(icon, fallback), False, False, 0)
            box.pack_start(Gtk.Label(label=t(key)), False, False, 0)
            btn = Gtk.Button()
            btn.add(box)
            btn.set_tooltip_text(t(key))
            btn.get_style_context().add_class("task-btn")
            btn.connect("clicked", lambda _b, f=action: f())
            bar.pack_start(btn, False, False, 0)
            self.btns[view] = btn
        clock = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.clock_time, self.clock_date = Gtk.Label(), Gtk.Label()
        self.clock_time.get_style_context().add_class("clock-time")
        self.clock_date.get_style_context().add_class("clock-date")
        clock.pack_start(self.clock_time, False, False, 0)
        clock.pack_start(self.clock_date, False, False, 0)
        bar.pack_end(clock, False, False, 10)
        self.battery = Gtk.Box(spacing=4, valign=Gtk.Align.CENTER)
        self.battery.get_style_context().add_class("battery")
        self.battery_icon = Gtk.Image.new_from_icon_name("battery-full-symbolic", Gtk.IconSize.BUTTON)
        self.battery_label = Gtk.Label()
        self.battery.pack_start(self.battery_icon, False, False, 0)
        self.battery.pack_start(self.battery_label, False, False, 0)
        bar.pack_end(self.battery, False, False, 4)
        power = Gtk.Button()
        power.add(_icon("power", "system-shutdown-symbolic", 20))
        power.set_tooltip_text(t("power.title"))
        power.get_style_context().add_class("task-btn")
        power.connect("clicked", self._power_menu)
        bar.pack_end(power, False, False, 0)
        self.add(bar)
        self._tick()
        GLib.timeout_add_seconds(1, self._tick)

        if os.path.exists(FLAG):
            self.toggle("terminal")
        else:
            self._show_welcome()

    # --- panel geometry ---
    def _reserve_space(self, *_):
        """Tell the window manager that the bottom strip is taken, so maximized windows stop above it."""
        g, h = self.geo, self.HEIGHT
        strut = [0, 0, 0, h, 0, 0, 0, 0, 0, 0, g.x, g.x + g.width - 1]
        try:
            xid = str(self.get_window().get_xid())
        except AttributeError:
            return
        for name, vals in (("_NET_WM_STRUT_PARTIAL", strut), ("_NET_WM_STRUT", strut[:4])):
            try:
                subprocess.call(["xprop", "-id", xid, "-f", name, "32c", "-set", name,
                                 ",".join(str(v) for v in vals)])
            except FileNotFoundError:
                return

    def _battery_info(self):
        """Return (available, percent, charging) from Linux power_supply.
        A desktop PC normally has no BAT* device, so the indicator stays hidden.
        """
        base = "/sys/class/power_supply"
        try:
            bats = [Path for Path in os.listdir(base) if Path.startswith("BAT")]
        except OSError:
            bats = []
        if not bats:
            return False, 0, False
        bat = os.path.join(base, sorted(bats)[0])
        try:
            cap = int(open(os.path.join(bat, "capacity"), encoding="utf-8").read().strip())
        except (OSError, ValueError):
            cap = 0
        try:
            status = open(os.path.join(bat, "status"), encoding="utf-8").read().strip().lower()
        except OSError:
            status = ""
        return True, max(0, min(100, cap)), status in {"charging", "full", "not charging"}

    def _battery_icon_name(self, percent, charging):
        if charging:
            return "battery-full-charging-symbolic"
        level = 20 if percent <= 20 else 40 if percent <= 40 else 60 if percent <= 60 else 80 if percent <= 80 else 100
        return f"battery-{level}-symbolic"

    def _tick(self):
        now = GLib.DateTime.new_now_local()
        self.clock_time.set_text(now.format("%H:%M"))
        self.clock_date.set_text(now.format("%d.%m.%Y"))
        available, percent, charging = self._battery_info()
        self.battery.set_visible(available)
        if available:
            self.battery_icon.set_from_icon_name(self._battery_icon_name(percent, charging), Gtk.IconSize.BUTTON)
            self.battery_label.set_text(f"{percent}%")
        self.spawned = [p for p in self.spawned if p.poll() is None]  # reap finished children
        self.refresh()
        return True  # keep the timer running

    # --- apps ---
    def _track(self, w, on_gone=None):
        w.connect("notify::is-active", lambda *_: self.refresh())
        w.connect("window-state-event", lambda *_: self.refresh())
        w.connect("destroy", lambda *_: on_gone() if on_gone else None)

    def toggle(self, view):
        """Open the app, or restore it if minimized, or minimize it if it is already in front."""
        w = self.wins.get(view)
        if w is None:
            factory = [a[4] for a in self.APPS if a[0] == view][0]
            w = self.wins[view] = factory()
            self._track(w, lambda: self._gone(view))
            w.show_all()
            w.present()
        elif w.iconified:
            w.deiconify()
            w.present()
        elif w.is_active():
            w.iconify()
        else:
            w.present()
        self.refresh()

    def launch(self, view, argv):
        """Start an external program (argv list, no shell). A running one just gets another window."""
        try:
            p = subprocess.Popen(argv)
        except OSError:
            return
        self.spawned.append(p)
        old = self.procs.get(view)
        if old is None or old.poll() is not None:
            self.procs[view] = p
        self.refresh()

    def _gone(self, view):
        self.wins.pop(view, None)
        self.refresh()

    def refresh(self):
        for view, btn in self.btns.items():
            if view in self.procs:
                _set_class(btn, "open", self.procs[view].poll() is None)
                continue
            w = self.wins.get(view)
            _set_class(btn, "open", w is not None)
            _set_class(btn, "active", w is not None and w.is_active() and not w.iconified)

    def _show_welcome(self):
        def start():
            try:
                os.makedirs(os.path.dirname(FLAG), exist_ok=True)
                open(FLAG, "w").close()
            except OSError:
                pass
            self.welcome.destroy()
            self.toggle("terminal")
        self.welcome = WelcomeWindow(start)
        self.welcome.show_all()

    # --- power ---
    def _power_menu(self, btn):
        self._menu = Gtk.Menu()
        for key, cmd in [("power.restart", "reboot"), ("power.shutdown", "poweroff")]:
            item = Gtk.MenuItem(label=t(key))
            item.connect("activate", lambda _i, c=cmd, k=key: self._power(c, k))
            self._menu.append(item)
        self._menu.show_all()
        self._menu.popup_at_widget(btn, Gdk.Gravity.NORTH_EAST, Gdk.Gravity.SOUTH_EAST, None)

    def _power(self, cmd, key):
        np = self.wins.get("notepad")
        if np is not None and not np.notepad.confirm_discard():
            return
        d = Gtk.MessageDialog(message_type=Gtk.MessageType.QUESTION, text=t(key.replace("power.", "power.ask_")))
        d.set_position(Gtk.WindowPosition.CENTER)
        d.set_keep_above(True)
        d.add_button(t("notepad.cancel"), Gtk.ResponseType.CANCEL)
        d.add_button(t(key), Gtk.ResponseType.ACCEPT)
        ok = d.run() == Gtk.ResponseType.ACCEPT
        d.destroy()
        if ok:
            _run_power(cmd)


def main():
    prov = Gtk.CssProvider()
    prov.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", True)
    # Prefer a hardware-friendly cursor theme and consistent pointer size.
    os.environ.setdefault("XCURSOR_THEME", "Adwaita")
    os.environ.setdefault("XCURSOR_SIZE", "24")
    Taskbar().show_all()
    Gtk.main()


if __name__ == "__main__":
    sys.exit(main())
