// Native probe: prints RAM and uptime using sysinfo(2). Used by future fast-path tools.
#include <sys/sysinfo.h>
#include <iostream>

int main() {
    struct sysinfo si;
    if (sysinfo(&si) != 0) { std::cerr << "sysinfo failed\n"; return 1; }
    const unsigned long mib = 1024UL * 1024UL;
    std::cout << "ram_total_mib=" << (si.totalram * si.mem_unit) / mib << "\n"
              << "ram_free_mib=" << (si.freeram * si.mem_unit) / mib << "\n"
              << "uptime_s=" << si.uptime << "\n";
    return 0;
}
