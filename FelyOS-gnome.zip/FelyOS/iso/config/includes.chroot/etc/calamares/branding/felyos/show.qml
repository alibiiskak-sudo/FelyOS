import QtQuick 2.0
import calamares.slideshow 1.0
Presentation {
    id: presentation
    Slide {
        Rectangle { anchors.fill: parent; color: "#12151c" }
        Text { anchors.centerIn: parent; text: "Installing FelyOS..."; color: "white"; font.pixelSize: 28 }
    }
}
