#!/bin/sh
# Build the FelyOS ISO. Run on Debian/Ubuntu as root:  sudo ./build.sh
set -e
[ "$(id -u)" -eq 0 ] || { echo "Run as root (sudo ./build.sh)"; exit 1; }
command -v lb >/dev/null || apt-get install -y live-build
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/scripts/stage.sh"
WORK=/tmp/felyos-build
rm -rf "$WORK" && mkdir -p "$WORK" && cd "$WORK"
lb config \
  --distribution bookworm \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --bootloaders "syslinux,grub-efi" \
  --debian-installer none \
  --archive-areas "main contrib non-free non-free-firmware" \
  --image-name felyos --iso-application FelyOS --iso-volume FelyOS-0.10 \
  --bootappend-live "boot=live components persistence quiet splash hostname=felyos username=user"
cp -r "$ROOT/iso/config/." config/
lb build
cp -v ./*.iso "$ROOT/FelyOS-0.10-amd64.iso"
